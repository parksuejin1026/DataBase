select addr from usertbl;
select addr from usertbl order by addr;
select distinct addr from usertbl;
